<?php
session_start();

// Konfigurasi koneksi database
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'user_login';

// Membuat koneksi ke database
$conn = mysqli_connect($host, $user, $password, $database);

// Periksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Hapus pengguna dari database
    $delete_query = "DELETE FROM users WHERE username = '$username'";
    mysqli_query($conn, $delete_query);

    // Hapus session
    session_unset();
    session_destroy();

    header("Location: login.php");
    exit();
}

// Tutup koneksi
mysqli_close($conn);
?>
