<?php
session_start();

// Konfigurasi koneksi database
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'user_login';

// Membuat koneksi ke database
$conn = mysqli_connect($host, $user, $password, $database);

// Periksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $ip_address = $_SERVER['REMOTE_ADDR'];

    // Update IP dan last_update setiap kali pengguna mengakses halaman ini
    $update_query = "UPDATE users SET ip_address = '$ip_address', last_update = NOW() WHERE username = '$username'";
    mysqli_query($conn, $update_query);
}

// Tutup koneksi
mysqli_close($conn);
?>
