<?php
session_start();

// Konfigurasi koneksi database
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'user_login';

// Membuat koneksi ke database
$conn = mysqli_connect($host, $user, $password, $database);

// Periksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Cek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$ip_address = $_SERVER['REMOTE_ADDR'];

// Update waktu terakhir pengguna aktif
$update_query = "UPDATE users SET last_update = NOW() WHERE username = '$username'";
mysqli_query($conn, $update_query);

// Ambil daftar semua pengguna dari database
$query = "SELECT username, ip_address, last_update, 
          IF(TIMESTAMPDIFF(SECOND, last_update, NOW()) < 15, 'Connected', 'Disconnected') as status 
          FROM users";
$result = mysqli_query($conn, $query);

$users = [];
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <style>
        .highlight {
            background-color: #f8d7da; /* Background merah */
            color: #721c24; /* Warna teks merah gelap */
        }
        .disconnected {
            background-color: #d4edda; /* Background hijau */
            color: #155724; /* Warna teks hijau gelap */
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function updateStatus() {
            $.ajax({
                url: 'update_status.php',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    let userList = $('#userList');
                    userList.empty();

                    // Cari IP address yang sama
                    let ipCounts = {};
                    data.forEach(function(user) {
                        if (ipCounts[user.ip_address]) {
                            ipCounts[user.ip_address]++;
                        } else {
                            ipCounts[user.ip_address] = 1;
                        }
                    });

                    data.forEach(function(user) {
                        let className = '';
                        if (ipCounts[user.ip_address] > 1) {
                            className = 'highlight';
                        }
                        if (user.status === 'Disconnected') {
                            className = className ? className + ' disconnected' : 'disconnected';
                        }
                        userList.append('<li class="' + className + '">' + user.username + ' (' + user.ip_address + ') - ' + user.status + '</li>');
                    });
                }
            });
        }

        function keepAlive() {
            $.ajax({
                url: 'keep_alive.php',
                method: 'POST',
                success: function() {
                    console.log('Keep alive sent');
                }
            });
        }

        $(document).ready(function() {
            // Update status setiap 5 detik
            setInterval(updateStatus, 5000);

            // Kirim sinyal 'keep alive' setiap 10 detik
            setInterval(keepAlive, 10000);

            // Update status pertama kali
            updateStatus();
        });
    </script>
</head>
<body>
    <h2>Welcome, <?php echo htmlspecialchars($username); ?></h2>
    <p>Your IP Address: <?php echo htmlspecialchars($ip_address); ?></p>

    <h3>User List:</h3>
    <ul id="userList">
        <!-- Daftar pengguna akan diisi di sini oleh JavaScript -->
    </ul>

    <a href="logout.php">Logout</a>
</body>
</html>
