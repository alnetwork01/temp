<?php
// Konfigurasi koneksi database
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'user_login';

// Membuat koneksi ke database
$conn = mysqli_connect($host, $user, $password, $database);

// Periksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil daftar semua pengguna dari database
$query = "SELECT username, ip_address, last_update, 
          IF(TIMESTAMPDIFF(SECOND, last_update, NOW()) < 15, 'Connected', 'Disconnected') as status 
          FROM users";
$result = mysqli_query($conn, $query);

$users = [];
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}

// Return data sebagai JSON
header('Content-Type: application/json');
echo json_encode($users);

// Tutup koneksi
mysqli_close($conn);
?>
