<?php
// Konfigurasi koneksi database
$host = 'localhost';
$user = 'root';
$password = '';

// Membuat koneksi ke MySQL
$conn = new mysqli($host, $user, $password);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Nama database yang ingin dibuat
$database = 'user_login';

// SQL query untuk membuat database
$sql = "CREATE DATABASE IF NOT EXISTS $database";

// Eksekusi query
if ($conn->query($sql) === TRUE) {
    echo "Database '$database' berhasil dibuat atau sudah ada.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Pilih database yang baru dibuat
$conn->select_db($database);

// SQL query untuk membuat tabel
$table_sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    last_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

// Eksekusi query untuk membuat tabel
if ($conn->query($table_sql) === TRUE) {
    echo "<br>Tabel 'users' berhasil dibuat atau sudah ada.";
} else {
    echo "<br>Error: " . $table_sql . "<br>" . $conn->error;
}

// Tutup koneksi
$conn->close();
?>
