<?php
session_start();

// Konfigurasi koneksi database
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'user_login';

// Membuat koneksi ke database
$conn = mysqli_connect($host, $user, $password, $database);

// Periksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Cek apakah form login sudah disubmit
if (isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $ip_address = $_SERVER['REMOTE_ADDR'];

    // Simpan username ke session
    $_SESSION['username'] = $username;

    // Cek apakah pengguna sudah ada di database
    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Jika pengguna sudah ada, update IP dan last_update
        $query = "UPDATE users SET ip_address = '$ip_address', last_update = NOW() WHERE username = '$username'";
    } else {
        // Jika pengguna belum ada, tambahkan ke database
        $query = "INSERT INTO users (username, ip_address) VALUES ('$username', '$ip_address')";
    }

    // Eksekusi query
    if (mysqli_query($conn, $query)) {
        // Redirect ke halaman list
        header("Location: list.php");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}

// Tutup koneksi
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <br><br>
        <button type="submit" name="submit">Login</button>
    </form>
</body>
</html>
